insert into address (id, address_line1, address_line2, city, postal_code)
            values (901, 'xx', 'yy', 'city', '60-400');

//wstawianie adresów
INSERT INTO address_entity (id, city, address_line1, address_line2, postal_code)
            VALUES
            (1, ('Warszawa', 'ul. Koszykowa 75', '', '00-662')
            (2, 'Krakow', 'ul. Długa 12', 'lok. 3', '31-147');

//wstawianie pacjentów
INSERT INTO patient_entity (id, first_name, last_name, telephone_number, email, patient_number, date_of_birth, address_id)
            VALUES
            (1, 'Jan', 'Kowalski', '987654321', 'jan.kowalski@patient.com', 'PAT001', '1990-05-20', 1)
            (2, 'Anna', 'Nowak', '987654321', 'anna.nowak@patient.com', 'PAT002', '1992-09-22', 2);

//wstawianie zabiegów medycznych
INSERT INTO medical_treatment_entity (id, description, type, visit_id)
            VALUES
            (1, 'EKG', 'DIAGNOSTIC', 1),
            (2, 'Rezonans magnetyczny', 'DIAGNOSTIC'), 2;

//wstawianie lekarzy
INSERT INTO doctor_entity (id, first_name, last_name, telephone_number, email, doctor_number, specialization, address_id)
            VALUES
            (1, 'Paulina', 'Nowak', '123456789', 'p.nowak@clinic.com', 'DOC001', 'CARDIOLOGIST', 1);
            (2, 'Ewa', 'Wójcik', '444555666', 'e.wojcik@clinicl.com','DOC002' 'NEUROLOGIST', 2);

//wstawianie wizyt
INSERT INTO visit_entity (id, description, time, doctor_id, patient_id, treatment_id)
            VALUES
            (1, 'Badanie kontrolne', '2024-04-10 10:00:00', 1, 1, 1);
            (2, 'Konsultacja neurologiczna', '2024-04-12 14:30:00', 2, 2, 2)
